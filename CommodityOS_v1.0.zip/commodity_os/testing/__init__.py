"""Automated testing framework."""
