"""Self-managing crawler framework."""
