"""Integration layer: CrawlSpiders → Data Pipeline → Knowledge Graph → Dashboard → GitHub.

Wires 10 CrawlSpiders (real HTTP-based) to the data pipeline, processes results through the
knowledge graph, generates dashboard, and publishes to GitHub Pages.
"""
import asyncio
import json
import logging
import random
import time
from pathlib import Path
from typing import Any, Dict, List

from commodity_os.core.events import event_bus, EventType
from commodity_os.core.orchestrator import ResourceAwareOrchestrator
from commodity_os.data_pipeline.pipeline import DataPipeline
from commodity_os.knowledge_graph.graph import KnowledgeGraph
from commodity_os.dashboard.generator import DashboardGenerator
from commodity_os.crawlers.spider import CrawlSpiderManager

logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "output"
DOCS_DIR = Path(__file__).resolve().parent.parent / "docs"


# ---------------------------------------------------------------------------
# Schema mapping: crawler output → data pipeline expected fields
# ---------------------------------------------------------------------------

def _map_crawler_record(record: Dict[str, Any]) -> Dict[str, Any]:
    """Transform a crawler-generated record into the schema the data pipeline expects."""
    contact = record.get("contact", {})
    pricing = record.get("pricing", {})
    geo = record.get("geography", {})

    return {
        "company_name": record.get("name", ""),
        "product": record.get("commodity", record.get("commodity_group", "")),
        "category": record.get("commodity_group", ""),
        "entity_type": record.get("entity_type", ""),
        "contact_phone": contact.get("phone", ""),
        "address": record.get("office_address", ""),
        "district": geo.get("district", record.get("district", "")),
        "state": geo.get("state", record.get("state", "")),
        "taluk": geo.get("taluk", record.get("taluk", "")),
        "email": contact.get("email", ""),
        "website": contact.get("website", ""),
        "gst_number": record.get("gst_number", ""),
        "year_of_establishment": record.get("year_of_establishment", ""),
        "market_price": pricing.get("market_price", 0),
        "purchase_price": pricing.get("purchase_price", 0),
        "selling_price": pricing.get("selling_price", 0),
        "price_unit": pricing.get("unit", "KG"),
        "currency": pricing.get("currency", "INR"),
        "payment_terms": record.get("payment_terms", ""),
        "delivery_available": record.get("delivery_available", False),
        "source": record.get("source", ""),
        "collected_at": record.get("collected_at", ""),
        "_raw": record,
    }


# ---------------------------------------------------------------------------
# Integration orchestrator
# ---------------------------------------------------------------------------

class IntegrationOrchestrator:
    """Wires the full pipeline: CrawlSpider → Process → Graph → Dashboard."""

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.spider_manager = CrawlSpiderManager()
        self.pipeline = DataPipeline()
        self.graph = KnowledgeGraph()
        self.orchestrator = ResourceAwareOrchestrator()

    async def run_collection_cycle(self) -> Dict[str, Any]:
        """Run a full collection cycle across all CrawlSpiders."""
        cycle_start = time.time()
        logger.info("=== Starting collection cycle (CrawlSpider) ===")

        # 1. Run orchestrator cycle to check resources
        await self.orchestrator.initialize()
        snap = await self.orchestrator.resource_monitor.snapshot()
        rec = self.orchestrator.resource_monitor.get_schedule_recommendation(snap)
        logger.info(f"Resources: CPU={snap.cpu_percent:.1f}% RAM={snap.ram_percent:.1f}% "
                     f"Health={self.orchestrator.resource_monitor.get_health_score(snap):.1f}")

        # 2. Collect raw data from all CrawlSpiders (real HTTP)
        all_raw_entities, spider_stats = await self.spider_manager.run_all()
        logger.info(f"Total raw entities collected: {len(all_raw_entities)}")

        # 3. Map crawler output to data pipeline schema
        mapped_records = [_map_crawler_record(e) for e in all_raw_entities]
        logger.info(f"Mapped {len(mapped_records)} records to pipeline schema")

        # 4. Run through data pipeline
        pipeline_result = await self.pipeline.run(mapped_records)
        logger.info(f"Pipeline result: {pipeline_result.records_in} → {pipeline_result.records_out} records")
        for stage in pipeline_result.stages:
            logger.info(f"  Stage {stage.stage_name}: {stage.input_count} → {stage.output_count} "
                        f"({stage.processing_time_ms:.1f}ms, {stage.errors} errors)")

        # 5. Add surviving records to knowledge graph
        graph_entities = 0
        graph_commodities = set()
        graph_geographies = set()

        for record in mapped_records:
            # Add entity
            name = record.get("company_name", "")
            if name:
                self.graph.add_entity({
                    "name": name,
                    "entity_type": record.get("entity_type", ""),
                    "source": record.get("source", ""),
                    "state": record.get("state", ""),
                    "district": record.get("district", ""),
                    "commodity": record.get("product", ""),
                })
                graph_entities += 1

                # Add commodity node and SUPPLIES relationship
                commodity = record.get("product", "")
                if commodity:
                    self.graph.add_commodity(commodity)
                    commodity_id = f"commodity:{commodity.lower().strip()}"
                    entity_id = f"entity:{name.lower().strip()}"
                    self.graph.add_relationship(entity_id, commodity_id, "SUPPLIES")
                    graph_commodities.add(commodity)

                # Add geography nodes and LOCATED_IN relationship
                state = record.get("state", "")
                district = record.get("district", "")
                if state:
                    self.graph.add_geography(state, "state")
                    state_id = f"geography:{state.lower().strip()}"
                    entity_id = f"entity:{name.lower().strip()}"
                    self.graph.add_relationship(entity_id, state_id, "LOCATED_IN")
                    graph_geographies.add(state)
                if district:
                    self.graph.add_geography(district, "district")

        logger.info(f"Knowledge graph: {graph_entities} entities, {len(graph_commodities)} commodities, "
                     f"{len(graph_geographies)} geographies")

        # 6. Save results - APPEND new entities (dedup by name+product+source)
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

        all_entities_file = OUTPUT_DIR / "all_entities.json"
        existing_entities = []
        if all_entities_file.exists():
            try:
                with open(all_entities_file, "r", encoding="utf-8") as f:
                    existing_entities = json.load(f)
            except (json.JSONDecodeError, IOError):
                existing_entities = []

        # Dedup: keep existing, add new ones not already present
        seen = set()
        for e in existing_entities:
            key = (e.get("name", ""), e.get("commodity", e.get("commodity_group", "")), e.get("source", ""))
            seen.add(key)

        new_count = 0
        for e in all_raw_entities:
            key = (e.get("name", ""), e.get("commodity", e.get("commodity_group", "")), e.get("source", ""))
            if key not in seen:
                existing_entities.append(e)
                seen.add(key)
                new_count += 1

        with open(all_entities_file, "w", encoding="utf-8") as f:
            json.dump(existing_entities, f, indent=2, ensure_ascii=False)
        logger.info(f"Entities: {len(existing_entities)} total ({new_count} new, {len(all_raw_entities)} in this cycle)")

        stats_file = OUTPUT_DIR / "pipeline_stats.json"
        with open(stats_file, "w", encoding="utf-8") as f:
            json.dump({
                "cycle": self._cycle_count if hasattr(self, '_cycle_count') else 0,
                "raw_entities": len(all_raw_entities),
                "pipeline_output": pipeline_result.records_out,
                "pipeline_stages": [s.__dict__ for s in pipeline_result.stages],
                "graph_stats": self.graph.get_stats(),
                "spider_stats": spider_stats,
                "resources": snap.to_dict(),
            }, f, indent=2, default=str)

        # 7. Discover relationships
        discovered = self.graph.discover_relationships()
        logger.info(f"Discovered relationships: {discovered}")

        # 8. Generate dashboard using ALL accumulated entities
        dash_gen = DashboardGenerator(str(OUTPUT_DIR))
        dashboard_entities = []
        for record in existing_entities:
            dashboard_entities.append({
                "name": record.get("name", record.get("company_name", "")),
                "type": record.get("entity_type", record.get("type", "")),
                "product": record.get("commodity", record.get("product", "")),
                "category": record.get("commodity_group", record.get("category", "")),
                "state": record.get("state", ""),
                "district": record.get("district", ""),
                "taluk": record.get("taluk", ""),
                "phone": record.get("contact", record.get("contact_phone", record.get("phone", ""))),
                "email": record.get("email", ""),
                "website": record.get("website", ""),
                "market_price": record.get("pricing", {}).get("market_price", record.get("market_price", 0)),
                "purchase_price": record.get("pricing", {}).get("purchase_price", record.get("purchase_price", 0)),
                "selling_price": record.get("pricing", {}).get("selling_price", record.get("selling_price", 0)),
                "unit": record.get("pricing", {}).get("unit", record.get("price_unit", "KG")),
                "source": record.get("source", ""),
                "year": record.get("year_of_establishment", record.get("year", "")),
                "gst": record.get("gst_number", record.get("gst", "")),
                "confidence": 0.8,
                "entity_type": record.get("entity_type", record.get("type", "")),
                "commodity_group": record.get("commodity_group", record.get("category", "")),
            })
        consolidated = {"entities": dashboard_entities, "stats": {"total": len(dashboard_entities)}}
        await dash_gen.generate(dashboard_entities, consolidated)

        # 9. Copy dashboard to docs/ for GitHub Pages
        DOCS_DIR.mkdir(parents=True, exist_ok=True)
        src_html = OUTPUT_DIR / "dashboard.html"
        if src_html.exists():
            import shutil
            shutil.copy2(src_html, DOCS_DIR / "index.html")
            logger.info("Dashboard copied to docs/index.html")

        src_json = OUTPUT_DIR / "dashboard.json"
        if src_json.exists():
            import shutil
            shutil.copy2(src_json, DOCS_DIR / "dashboard.json")
            logger.info("Dashboard JSON copied to docs/")

        # 10. Copy dashboard JSON to docs/data.json for frontend auto-refresh
        dashboard_json = OUTPUT_DIR / "dashboard.json"
        if dashboard_json.exists():
            import shutil
            shutil.copy2(dashboard_json, DOCS_DIR / "data.json")
            logger.info("Dashboard JSON copied to docs/data.json for frontend")
            logger.info("Entity data copied to docs/data.json")

        cycle_duration = time.time() - cycle_start
        summary = {
            "cycle_duration_seconds": round(cycle_duration, 2),
            "raw_entities_collected": len(all_raw_entities),
            "pipeline_records_in": pipeline_result.records_in,
            "pipeline_records_out": pipeline_result.records_out,
            "graph_nodes": self.graph.graph.number_of_nodes(),
            "graph_edges": self.graph.graph.number_of_edges(),
            "spider_stats": spider_stats,
            "health_score": self.orchestrator.resource_monitor.get_health_score(snap),
        }
        logger.info(f"=== Collection cycle complete in {cycle_duration:.1f}s ===")
        return summary

    async def shutdown(self):
        await self.orchestrator.shutdown()
        await self.spider_manager.close_all()
        logger.info("Integration orchestrator shut down")
