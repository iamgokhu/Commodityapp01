"""Dashboard generation."""
