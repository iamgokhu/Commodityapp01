"""Data processing pipeline."""
